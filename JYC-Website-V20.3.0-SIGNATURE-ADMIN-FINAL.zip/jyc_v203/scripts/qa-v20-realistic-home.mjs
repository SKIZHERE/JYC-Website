import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
const main=read('src/main.jsx'); const css=read('src/v20-realistic-home.css'); const pkg=JSON.parse(read('package.json')); const sw=read('public/sw.js');
const checks=[
 ['version is 20.3.0',pkg.version==='20.3.0'],
 ['realistic home is mounted',main.includes('home-realistic')&&main.includes('realistic-hero')],
 ['hero uses published content',main.includes('publishedEvents')&&main.includes('moments=data.gallery.filter')],
 ['legacy hero figures restored',main.includes('<HeroStats />')&&main.includes('function HeroStats({communities=25,campuses=2,fests=2,since=2008})')],
 ['real gallery moment is used',main.includes('heroMoment.url')],
 ['responsive desktop grid',css.includes('grid-template-columns:minmax(0,1.02fr)')],
 ['responsive tablet layout',css.includes('@media(max-width:1100px)')],
 ['responsive mobile layout',css.includes('@media(max-width:760px)')],
 ['small mobile layout',css.includes('@media(max-width:420px)')],
 ['light paper palette',css.includes('--jyc-paper:#f4ead5')],
 ['dark fallback preserved',css.includes(':root[data-theme="dark"] .home-realistic')],
 ['reduced motion handled',css.includes('@media(prefers-reduced-motion:reduce)')],
 ['service worker bumped',sw.includes('jyc-cache-v20-2-admin-orbit-polish')],
 ['V20 stylesheet imported last',main.includes("import './v20-realistic-home.css';")&&main.includes("import './v20.1-hero-finish.css';")&&main.includes("import './v20.2-final-polish.css';")&&main.includes("import './v20.3-signature-fix.css';")],
 ['ecosystem orbital section restored',main.includes('<EcosystemSection data={data}/>')&&main.includes("'ecosystem'")],
 ['third hero orbital ring restored',main.includes('orbit-c')],
 ['admin top chrome is sticky',read('src/v20.3-signature-fix.css').includes('.admin-top {')&&read('src/v20.3-signature-fix.css').includes('position:sticky')],
 ['admin sidebar remains sticky',read('src/v20.3-signature-fix.css').includes('.admin-side {')&&read('src/v20.3-signature-fix.css').includes('height:100svh')],
 ['AI unavailable state is non-destructive',read('src/v20.3-signature-fix.css').includes('.admin-ai-panel .error-box')&&read('src/admin-chunk.jsx').includes('Local editorial checks are available')],
]; let pass=0; for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'}: ${name}`); if(ok)pass++;} if(pass!==checks.length)process.exit(1); console.log(`V20 realistic home QA: ${pass}/${checks.length}`);
